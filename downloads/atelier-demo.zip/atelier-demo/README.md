# Atelier demo

The demo app for Browser Visual Editor. It needs Node.js and nothing else: no Git, no GitHub account.

1. Install **Node.js** (the LTS version) from https://nodejs.org if it is not installed.
2. Start the demo:
   - **Windows:** double-click `START.cmd`.
   - **macOS:** double-click `start.command`. If macOS blocks it, right-click it and choose Open.
   - **Any system:** open a terminal in this folder and run `npm install`, then `npm run dev`.
3. The demo opens at http://127.0.0.1:5173. The first start downloads its packages and takes a minute. Keep the window open while you edit; close it to stop the demo.
4. In Chrome, with the Browser Visual Editor extension loaded, open that address and press Alt+Shift+E. When asked for the project folder, choose this folder (the one that contains `package.json`).
