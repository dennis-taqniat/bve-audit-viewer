import { Features } from '@/components/site/features';
import { Hero } from '@/components/site/hero';
import { Newsletter } from '@/components/site/newsletter';
import { SiteFooter } from '@/components/site/footer';
import { SiteHeader } from '@/components/site/header';
import { Workflow } from '@/components/site/workflow';

export function App() {
  return (
    <div className="min-h-dvh bg-background text-foreground">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded-md focus:bg-primary focus:px-4 focus:py-2 focus:text-primary-foreground">
        Skip to content
      </a>
      <SiteHeader />
      <main id="main">
        <Hero />
        <Features />
        <Workflow />
        <Newsletter />
      </main>
      <SiteFooter />
    </div>
  );
}
