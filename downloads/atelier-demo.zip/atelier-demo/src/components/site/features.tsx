import { FileDiff, MousePointerClick, SlidersHorizontal } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

const steps = [
  { icon: MousePointerClick, title: 'Pick an element', body: 'Select anything on the page. Atelier finds the line of source that renders it, and says how sure it is.' },
  { icon: SlidersHorizontal, title: 'Change it', body: 'Adjust spacing, type, colour and borders with live controls. The page updates as you go; your files do not.' },
  { icon: FileDiff, title: 'Review the diff', body: 'See exactly which lines will change, choose where a shared style should be edited, then approve or walk away.' },
];

export function Features() {
  return (
    <section id="how" aria-labelledby="how-title" className="border-y bg-muted/40">
      <div className="mx-auto max-w-5xl px-6 py-16">
        <h2 id="how-title" className="font-sans text-[50px] font-extrabold tracking-tight">How it works</h2>
        <p className="mt-3 max-w-2xl text-muted-foreground">Three steps, in the order you would do them by hand.</p>
        <ol className="mt-10 grid gap-6 md:grid-cols-3">
          {steps.map((s, i) => (
            <li key={s.title}>
              <Card className="h-full">
                <CardHeader>
                  <div className="mb-2 flex items-center gap-3">
                    <span className="grid size-9 place-items-center rounded-lg bg-accent text-accent-foreground">
                      <s.icon className="size-5" aria-hidden />
                    </span>
                    <span className="text-sm font-medium text-muted-foreground tabular-nums">Step {i + 1}</span>
                  </div>
                  <CardTitle role="heading" aria-level={3} className="text-lg">{s.title}</CardTitle>
                  <CardDescription className="leading-relaxed">{s.body}</CardDescription>
                </CardHeader>
                <CardContent />
              </Card>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
