import { Button } from '@/components/ui/button';

const links = [
  { href: '#how', label: 'How it works' },
  { href: '#details', label: 'Details' },
  { href: '#notes', label: 'Notes' },
];

export function SiteHeader() {
  return (
    <header className="border-b">
      <div className="mx-auto flex h-16 max-w-5xl items-center justify-between gap-4 px-6 text-2xl pt-5">
        <a href="/" className="flex items-center gap-2 rounded-md font-serif text-xl font-semibold tracking-tight outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50">
          <span aria-hidden className="grid size-7 place-items-center rounded-md bg-primary text-sm text-primary-foreground">A</span>
          Atelier
        </a>
        <nav aria-label="Primary" className="hidden items-center gap-1 sm:flex">
          {links.map((l) => (
            <Button key={l.href} variant="ghost" size="sm" asChild>
              <a href={l.href}>{l.label}</a>
            </Button>
          ))}
        </nav>
        <Button size="sm">Open the editor</Button>
      </div>
    </header>
  );
}
