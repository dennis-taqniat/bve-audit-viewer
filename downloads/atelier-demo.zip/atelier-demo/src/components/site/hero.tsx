import { ShieldCheck } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export function Hero() {
  return (
    <section className="mx-auto max-w-5xl px-6 pb-16 pt-16 sm:pt-24">
      <div className="grid items-center gap-12 md:grid-cols-[1.15fr_1fr]">
        <div>
          <Badge variant="secondary" className="mb-6">Local first</Badge>
          <h1 className="max-w-3xl text-balance font-[family-name:system-ui,-apple-system,Segoe_UI,Roboto,sans-serif] text-5xl font-extrabold tracking-tight sm:text-[120px] text-[#000000]">
            Small tools for careful work
          </h1>
          <p className="mt-6 max-w-xl text-pretty text-lg leading-relaxed text-muted-foreground">
            Atelier turns a change you make on the page into a reviewed edit to your own source. You look at the interface, you
            decide, and the diff stays small enough to read.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Button size="lg" style={{ backgroundColor: '#7f23fe' }}>Get started</Button>
            <Button size="lg" variant="outline">Read more</Button>
          </div>
        </div>

        <Card aria-label="Example of a reviewed change" className="gap-0 overflow-hidden py-0 shadow-sm">
          <CardHeader className="border-b bg-muted/40 px-5 py-3">
            <CardTitle className="font-mono text-xs font-medium text-muted-foreground">src/styles.css</CardTitle>
          </CardHeader>
          <CardContent className="px-0 py-3 font-mono text-[13px] leading-6">
            <pre className="overflow-x-auto"><code className="block">
              <span className="block px-5 text-muted-foreground">.hero-title {'{'}</span>
              <span className="block bg-red-50 px-5 text-red-800 dark:bg-red-950/50 dark:text-red-200"><span aria-hidden>− </span><span className="sr-only">removed: </span>  font-size: 48px;</span>
              <span className="block bg-emerald-50 px-5 text-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-200"><span aria-hidden>+ </span><span className="sr-only">added: </span>  font-size: 56px;</span>
              <span className="block px-5 text-muted-foreground">  line-height: 1.1;</span>
              <span className="block px-5 text-muted-foreground">{'}'}</span>
            </code></pre>
          </CardContent>
        </Card>
      </div>

      <Alert className="mt-14 max-w-2xl">
        <ShieldCheck />
        <AlertTitle>Your files stay the source of truth</AlertTitle>
        <AlertDescription>
          Nothing is written until you approve the exact diff. Every edit can be undone from the same place.
        </AlertDescription>
      </Alert>
    </section>
  );
}
