import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export function Workflow() {
  return (
    <section id="details" aria-labelledby="details-title" className="mx-auto max-w-5xl px-6 py-16">
      <h2 id="details-title" className="font-serif text-3xl font-semibold tracking-tight">Details</h2>
      <p className="mt-3 max-w-2xl text-muted-foreground">What it edits, what it refuses to guess, and how you get back.</p>
      <Tabs defaultValue="details" className="mt-8">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="details" className="text-[#cc7575] hover:text-[#ce2c2c]">Details</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
        </TabsList>
        <TabsContent value="overview">
          <Card>
            <CardHeader>
              <CardTitle role="heading" aria-level={3}>Overview</CardTitle>
              <CardDescription>A visual editor that writes ordinary code.</CardDescription>
            </CardHeader>
            <CardContent className="max-w-2xl leading-relaxed text-muted-foreground">
              Atelier reads your React and CSS, maps what you select back to the source, and proposes the smallest change that
              produces what you see. Formatting, comments and everything you did not touch stay byte for byte.
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="details">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle role="heading" aria-level={3}>Understands your styles</CardTitle>
                <CardDescription>Plain CSS, Modules, Tailwind, SCSS, inline.</CardDescription>
              </CardHeader>
              <CardContent className="text-sm leading-relaxed text-muted-foreground">
                Where a rule is shared by several elements, you choose whether the change applies to every use or only this one, and
                the diff shows which.
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle role="heading" aria-level={3}>Refuses to guess</CardTitle>
                <CardDescription>Ambiguous means nothing is written.</CardDescription>
              </CardHeader>
              <CardContent className="text-sm leading-relaxed text-muted-foreground">
                When two places could be the source and the page cannot say which, Atelier lists both and writes nothing until
                you pick.
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="history">
          <Card>
            <CardHeader>
              <CardTitle role="heading" aria-level={3}>History</CardTitle>
              <CardDescription>Undo and redo work against your files, not just the page.</CardDescription>
            </CardHeader>
            <CardContent className="max-w-2xl leading-relaxed text-muted-foreground">
              If a file changed in your editor since Atelier wrote it, undo stops and tells you instead of overwriting your work.
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </section>
  );
}
