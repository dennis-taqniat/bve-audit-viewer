import { useState, type FormEvent } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

export function Newsletter() {
  const [sent, setSent] = useState(false);
  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSent(true);
  };
  return (
    <section id="notes" aria-labelledby="notes-title" className="mx-auto max-w-5xl px-6 pb-24">
      <Card className="mx-auto max-w-xl">
        <CardHeader>
          <CardTitle id="notes-title" role="heading" aria-level={2} className="font-serif text-2xl">Release notes, rarely</CardTitle>
          <CardDescription>A short email when something changes that you would want to know about.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={onSubmit} className="grid gap-3" noValidate={false}>
            <Label htmlFor="email">Email address</Label>
            <div className="flex flex-col gap-3 sm:flex-row">
              <Input id="email" type="email" name="email" autoComplete="email" required placeholder="you@example.com" className="h-11 sm:flex-1" />
              <Button type="submit" size="lg" className="h-11">Subscribe</Button>
            </div>
            <p id="email-hint" className="text-sm text-muted-foreground">No tracking, and you can leave with one click.</p>
            <p role="status" aria-live="polite" className="min-h-5 text-sm font-medium text-primary">
              {sent ? 'Thanks. Check your inbox to confirm.' : ''}
            </p>
          </form>
        </CardContent>
      </Card>
    </section>
  );
}
