export function SiteFooter() {
  return (
    <footer className="border-t">
      <div className="mx-auto flex max-w-5xl flex-col gap-2 px-6 py-8 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
        <p>All rights reserved</p>
        <p>Built with shadcn/ui and the TDC design tokens.</p>
      </div>
    </footer>
  );
}
