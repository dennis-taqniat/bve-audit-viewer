import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import { bveSource } from './vendor/bve-vite-plugin.js';
import path from 'node:path';
import { defineConfig } from 'vite';

// bveSource stamps data-bve-source on elements (dev server only) so the Visual Editor can map them exactly.
export default defineConfig({
  plugins: [bveSource(), tailwindcss(), react()],
  resolve: { alias: { '@': path.resolve(import.meta.dirname, 'src') } },
});
